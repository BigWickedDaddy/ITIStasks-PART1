﻿using System;

namespace _27N
{
    class Program    //4 Задача
    // Находит колво 3-ёх значных чисел сумма которых N >= 1 && N <= 27
    {
        static void Main(string[] args)
        {
            BeforeAndAfter27();
            Console.ReadKey();
        }

        static void BeforeAndAfter27()
        {
            int sumOfNumbers = 0;
            int S = 0;
            for (int i = 100; i<=999; i++)
            {
                sumOfNumbers = int.Parse(i.ToString()[0].ToString()) + int.Parse(i.ToString()[1].ToString()) + int.Parse(i.ToString()[2].ToString());
                if (sumOfNumbers >= 1 && sumOfNumbers <= 27)
                {
                    S += 1;
                }
                sumOfNumbers = 0;
            }
            Console.WriteLine(S);
        }
    }
}
