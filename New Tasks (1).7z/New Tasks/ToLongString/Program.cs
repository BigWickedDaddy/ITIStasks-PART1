﻿using System;

namespace ToLongString
{
    class Program //2.0
                    // Находит длинную строку из однаковых чисел, ретёрнит её
    {
        static void Main(string[] args)
        {
            SearchingLongStr(Console.ReadLine());
        }

        static string SearchingLongStr(string userInput)
        {
            string firstStr = userInput[0].ToString();
            string secondStr = "";
            for (int i = 0; i < userInput.Length - 1; i++)
            {
                if ((userInput[i].ToString()) == (userInput[i + 1].ToString()))
                {
                    firstStr = firstStr + userInput[i+1].ToString();
                }
                else
                {
                    if (firstStr.Length >= secondStr.Length)
                    {
                        secondStr = firstStr;
                        firstStr = userInput[i+1].ToString();
                    }
                    else
                    {
                        firstStr = userInput[i+1].ToString();
                    }
                }
            }
            if (secondStr.Length <= firstStr.Length)
            {
                secondStr = firstStr;
            }
            Console.WriteLine(secondStr);
            return " ";
        }
    }
}
