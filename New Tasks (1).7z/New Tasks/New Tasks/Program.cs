﻿using System;

namespace New_Tasks
{
    class Program // 2.1
                    // Удаляет ненужные буквы, оставляет одну
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите последовательность букв");
            string userInput = Console.ReadLine();
           
            Console.WriteLine(DeletingWords(userInput));
        }

        static string DeletingWords(string userInput)
        {
            string firstSimb = "";
            string totalWord = "";
            firstSimb = userInput[0].ToString();
            totalWord = totalWord + firstSimb;
            for (int i = 0; i < userInput.Length; i++)
            {
                if (userInput[i].ToString() != firstSimb)
                {
                    totalWord = totalWord + userInput[i];
                    firstSimb = userInput[i].ToString();
                }
            }
            return totalWord;
        }

    }
}
